function _1(md){return(
md`# AI Adoption VS Employment Rates`
)}

function _data(FileAttachment){return(
FileAttachment("ai_jobs_merged_dataset.xlsx").xlsx().then(wb => {
  const sheet = wb.sheet(0, {headers: true});
  return sheet.map(d => ({
    ...d,
    posting_year:          +d["posting_year"],
    salary_usd:            +d["salary_usd"],
    ai_intensity_score:    +d["ai_intensity_score"],
    automation_risk_score: +d["automation_risk_score"],
    salary_change:         +d["salary_change_vs_prev_year_percent"],
    ai_index_score:        +d["ai_index_total_score"] || null,
    ai_mentioned:          d["ai_mentioned"] === true || d["ai_mentioned"] === "TRUE" || d["ai_mentioned"] === "true",
    reskilling_required:   d["reskilling_required"] === true || d["reskilling_required"] === "TRUE" || d["reskilling_required"] === "true",
  }));
})
)}

function _industryFilter(Inputs,data){return(
Inputs.select(
  ["All", ...new Set(data.map(d => d.industry))].sort(),
  { label: "Industry", value: "All" }
)
)}

function _seniorityFilter(Inputs,data){return(
Inputs.select(
  ["All", ...new Set(data.map(d => d.seniority_level))].sort(),
  { label: "Seniority", value: "All" }
)
)}

function _sizeFilter(Inputs,data){return(
Inputs.select(
  ["All", ...new Set(data.map(d => d.company_size))].sort(),
  { label: "Company size", value: "All" }
)
)}

function _riskFilter(Inputs){return(
Inputs.select(
  ["All", "Low", "Medium", "High"],
  { label: "Displacement risk", value: "All" }
)
)}

function _adoptionFilter(Inputs,data){return(
Inputs.select(
  ["All", ...new Set(data.map(d => d.industry_ai_adoption_stage))].sort(),
  { label: "AI adoption stage", value: "All" }
)
)}

function _yearMax(Inputs,d3,data){return(
Inputs.range(
  d3.extent(data, d => d.posting_year),
  { label: "Show years up to", step: 1, value: d3.max(data, d => d.posting_year) }
)
)}

function _aiOnly(Inputs){return(
Inputs.toggle({ label: "AI-mentioned jobs only", value: false })
)}

function _filtered(data,industryFilter,seniorityFilter,sizeFilter,riskFilter,adoptionFilter,yearMax,aiOnly){return(
data.filter(d =>
  (industryFilter === "All" || d.industry === industryFilter) &&
  (seniorityFilter === "All" || d.seniority_level === seniorityFilter) &&
  (sizeFilter === "All" || d.company_size === sizeFilter) &&
  (riskFilter === "All" || d.ai_job_displacement_risk === riskFilter) &&
  (adoptionFilter === "All" || d.industry_ai_adoption_stage === adoptionFilter) &&
  d.posting_year <= yearMax &&
  (!aiOnly || d.ai_mentioned === true)
)
)}

function _11(filtered,d3,htl)
{
  const n = filtered.length;
  const pctAI = (d3.mean(filtered, d => d.ai_mentioned ? 1 : 0) * 100).toFixed(1);
  const avgSal = d3.mean(filtered, d => d.salary_usd);
  const avgRisk = (d3.mean(filtered, d => d.automation_risk_score) * 100).toFixed(1);
  const pctResk = (d3.mean(filtered, d => d.reskilling_required ? 1 : 0) * 100).toFixed(0);
  const avgAI = d3.mean(filtered, d => d.ai_intensity_score).toFixed(3);
 
  return htl.html`<div style="display:grid;grid-template-columns:repeat(5,1fr);gap:12px;margin:12px 0">
    ${[
      ["Total jobs",          n.toLocaleString()],
      ["AI-mentioned",        pctAI + "%"],
      ["Avg salary",          "$" + Math.round(avgSal / 1000) + "K"],
      ["Avg automation risk", avgRisk + "%"],
      ["Reskilling required", pctResk + "%"],
    ].map(([label, val]) => htl.html`
      <div style="background:#f4f6ff;border:1px solid #dde3f5;border-radius:10px;padding:14px 16px;text-align:center">
        <div style="font-size:11px;font-weight:600;color:#6b7280;text-transform:uppercase;letter-spacing:.5px;margin-bottom:6px">${label}</div>
        <div style="font-size:24px;font-weight:700;color:#1a1a2e">${val}</div>
      </div>`
    )}
  </div>`
}


function _12(d3,filtered,Plot)
{
  const byYear = d3.rollups(
    filtered,
    v => d3.mean(v, d => d.ai_mentioned ? 1 : 0) * 100,
    d => d.posting_year
  ).map(([year, pct]) => ({ year, pct })).sort((a, b) => a.year - b.year);
 
  return Plot.plot({
    title: "AI mention rate in job postings over time",
    width: 900, height: 260,
    x: { label: "Year", tickFormat: d3.format("d") },
    y: { label: "% of postings mentioning AI", domain: [0, 100] },
    marks: [
      Plot.areaY(byYear, { x: "year", y: "pct", fill: "#3266ad", fillOpacity: 0.12 }),
      Plot.lineY(byYear, { x: "year", y: "pct", stroke: "#3266ad", strokeWidth: 2.5 }),
      Plot.dot(byYear, {
        x: "year", y: "pct", fill: "#3266ad", r: 5,
        title: d => `${d.year}: ${d.pct.toFixed(1)}%`
      }),
      Plot.text(byYear, {
        x: "year", y: "pct", text: d => d.pct.toFixed(1) + "%",
        dy: -12, fontSize: 11, fill: "#3266ad"
      })
    ]
  })
}


function _13(d3,filtered,Plot)
{
  const byIndustry = d3.rollups(
    filtered,
    v => d3.mean(v, d => d.ai_intensity_score),
    d => d.industry
  ).map(([industry, avg]) => ({ industry, avg }));
 
  return Plot.plot({
    title: "Average AI intensity score by industry",
    width: 700, height: 300,
    marginLeft: 110,
    x: { label: "Avg AI intensity score", domain: [0, 1] },
    y: { label: null },
    color: { scheme: "blues" },
    marks: [
      Plot.barX(byIndustry, {
        x: "avg", y: "industry",
        fill: "avg",
        sort: { y: "-x" },
        title: d => `${d.industry}: ${d.avg.toFixed(3)}`
      }),
      Plot.ruleX([0])
    ]
  })
}


function _14(filtered,Plot)
{
  const sample = filtered.filter((_, i) => i % 3 === 0);
 
  return Plot.plot({
    title: "Salary vs. automation risk score",
    width: 800, height: 380,
    x: { label: "Automation risk score (0–1)" },
    y: { label: "Salary (USD)" },
    color: { legend: true, label: "Displacement risk" },
    marks: [
      Plot.dot(sample, {
        x: "automation_risk_score",
        y: "salary_usd",
        fill: "ai_job_displacement_risk",
        r: 3, fillOpacity: 0.55,
        title: d => `${d.job_title}\n$${d.salary_usd.toLocaleString()}\nRisk: ${d.ai_job_displacement_risk}`
      }),
      Plot.linearRegressionY(sample, {
        x: "automation_risk_score", y: "salary_usd",
        stroke: "#c00", strokeWidth: 1.5, strokeDasharray: "5,3"
      })
    ]
  })
}


function _15(d3,filtered,Plot)
{
  const grouped = d3.rollups(
    filtered,
    v => {
      const total = v.length;
      return ["Low", "Medium", "High"].map(risk => ({
        industry: v[0].industry,
        risk,
        count: v.filter(d => d.ai_job_displacement_risk === risk).length,
        pct: (v.filter(d => d.ai_job_displacement_risk === risk).length / total) * 100
      }));
    },
    d => d.industry
  ).flatMap(([, rows]) => rows);

  return Plot.plot({
    title: "Displacement risk breakdown by industry (absolute count)",
    width: 800, height: 300,
    marginLeft: 110,
    x: { label: "Number of jobs" },
    y: { label: null },
    color: {
      domain: ["Low", "Medium", "High"],
      range: ["#4caf50", "#ff9800", "#e53935"],
      legend: true
    },
    marks: [
      Plot.barX(grouped, {
        x: "count", y: "industry", fill: "risk",
        sort: { y: "-x" },
        title: d => `${d.industry} — ${d.risk}: ${d.count} jobs (${d.pct.toFixed(1)}%)`
      })
    ]
  })
}


function _16(Plot,filtered)
{
  const order = ["Intern", "Junior", "Mid", "Lead", "Senior", "Executive"];
 
  return Plot.plot({
    title: "AI intensity score by seniority level",
    width: 700, height: 320,
    x: { label: "Seniority", domain: order },
    y: { label: "AI intensity score", domain: [0, 1] },
    color: { scheme: "blues" },
    marks: [
      Plot.boxY(filtered, {
        x: "seniority_level", y: "ai_intensity_score",
        fill: "seniority_level"
      })
    ]
  })
}


function _17(d3,filtered,Plot)
{
  const sizeOrder = ["Startup", "Small", "Medium", "Large", "Enterprise"];
  const senOrder  = ["Intern", "Junior", "Mid", "Senior", "Lead", "Executive"];
 
  const bySenioritySize = d3.rollups(
    filtered,
    v => d3.mean(v, d => d.salary_usd),
    d => d.seniority_level,
    d => d.company_size
  ).flatMap(([seniority, sizes]) =>
    sizes.map(([company_size, avg_salary]) => ({ seniority, company_size, avg_salary }))
  );
 
  return Plot.plot({
    title: "Average salary — seniority × company size",
    width: 800, height: 380,
    marginLeft: 90,
    x: { label: "Avg salary (USD)" },
    y: { label: null, domain: sizeOrder },
    color: { legend: true, label: "Company size" },
    facet: { data: bySenioritySize, y: "seniority", label: null },
    fy: { domain: senOrder },
    marks: [
      Plot.barX(bySenioritySize, {
        x: "avg_salary", y: "company_size", fill: "company_size",
        sort: { y: "-x" },
        title: d => `${d.seniority} / ${d.company_size}: $${Math.round(d.avg_salary).toLocaleString()}`
      }),
      Plot.ruleX([0])
    ]
  })
}


function _18(d3,filtered,Plot)
{
  const byStage = d3.rollups(
    filtered,
    v => d3.mean(v, d => d.reskilling_required ? 1 : 0) * 100,
    d => d.industry_ai_adoption_stage
  ).map(([stage, pct]) => ({ stage, pct }));
 
  return Plot.plot({
    title: "% requiring reskilling by AI adoption stage",
    width: 500, height: 280,
    x: { label: "AI adoption stage" },
    y: { label: "% requiring reskilling", domain: [0, 100] },
    marks: [
      Plot.barY(byStage, {
        x: "stage", y: "pct",
        fill: "stage",
        title: d => `${d.stage}: ${d.pct.toFixed(1)}%`
      }),
      Plot.ruleY([0])
    ]
  })
}


function _19(filtered,Plot)
{
  const withIndex = filtered.filter(d => d.ai_index_score && d.ai_index_score > 0);
 
  return Plot.plot({
    title: "Country AI index score vs. job salary",
    width: 800, height: 380,
    x: { label: "Country AI index total score" },
    y: { label: "Salary (USD)" },
    color: { legend: true, label: "Income group" },
    marks: [
      Plot.dot(withIndex, {
        x: "ai_index_score",
        y: "salary_usd",
        fill: "ai_index_income_group",
        r: 3, fillOpacity: 0.55,
        title: d => `${d.country}\nAI Index: ${d.ai_index_score}\n$${d.salary_usd.toLocaleString()}`
      }),
      Plot.linearRegressionY(withIndex, {
        x: "ai_index_score", y: "salary_usd",
        stroke: "#c00", strokeWidth: 1.5, strokeDasharray: "5,3"
      })
    ]
  })
}


function _20(d3,filtered,Plot)
{
  const byYearIndustry = d3.rollups(
    filtered,
    v => d3.mean(v, d => d.salary_change),
    d => d.industry,
    d => d.posting_year
  ).flatMap(([industry, years]) =>
    years
      .sort(([a], [b]) => d3.ascending(a, b))
      .map(([year, avg]) => ({ year, industry, avg }))
  );

  return Plot.plot({
    title: "Average year-over-year salary change by industry",
    width: 900,
    height: 420,
    marginRight: 120,
    x: { label: "Year", tickFormat: d3.format("d") },
    y: { label: "Avg YoY salary change (%)", grid: true },
    color: { legend: true, label: "Industry" },
    marks: [
      Plot.lineY(byYearIndustry, {
        x: "year",
        y: "avg",
        stroke: "industry",
        strokeWidth: 2,
        strokeOpacity: 0.75,
        z: "industry",
        title: d => `${d.industry} ${d.year}: ${d.avg.toFixed(1)}%`
      }),
      Plot.dot(byYearIndustry, {
        x: "year",
        y: "avg",
        fill: "industry",
        r: 2,
        opacity: 0.7,
        title: d => `${d.industry} ${d.year}: ${d.avg.toFixed(1)}%`
      }),
      Plot.ruleY([0])
    ]
  });
}


function _21(d3,filtered,Plot)
{
  const heatData = d3.rollups(
    filtered,
    v => d3.mean(v, d => d.automation_risk_score),
    d => d.industry,
    d => d.seniority_level
  ).flatMap(([industry, seniorities]) =>
    seniorities.map(([seniority, avg]) => ({ industry, seniority, avg }))
  );
 
  return Plot.plot({
    title: "Automation risk heatmap — industry × seniority",
    width: 700, height: 300,
    marginLeft: 110,
    x: {
    label: "seniority",
    domain: ["Intern", "Junior", "Mid", "Senior", "Lead", "Executive"]
  },

    color: {
      scheme: "RdYlGn",
      reverse: true,
      legend: true,
      label: "Avg automation risk"
    },
    marks: [
      Plot.cell(heatData, {
        x: "seniority", y: "industry",
        fill: "avg",
        inset: 0.5,
        title: d => `${d.industry} / ${d.seniority}: ${d.avg.toFixed(2)}`
      }),
      Plot.text(heatData, {
        x: "seniority", y: "industry",
        text: d => d.avg.toFixed(2),
        fontSize: 11,
        fill: d => d.avg > 0.6 ? "white" : "black"
      })
    ]
  })
}


function _22(d3,filtered,Plot)
{
  const numVars = [
    { key: "ai_intensity_score",    label: "AI intensity" },
    { key: "automation_risk_score", label: "Automation risk" },
    { key: "salary_usd",            label: "Salary" },
    { key: "salary_change",         label: "Salary YoY Δ" },
    { key: "ai_index_score",        label: "AI index score" },
  ];
 
  function pearson(arr, ka, kb) {
    const rows = arr.filter(d => d[ka] && d[kb]);
    const ma = d3.mean(rows, d => d[ka]);
    const mb = d3.mean(rows, d => d[kb]);
    const num = d3.sum(rows, d => (d[ka] - ma) * (d[kb] - mb));
    const den = Math.sqrt(
      d3.sum(rows, d => (d[ka] - ma) ** 2) *
      d3.sum(rows, d => (d[kb] - mb) ** 2)
    );
    return den === 0 ? 0 : num / den;
  }
 
  const corrData = numVars.flatMap(va =>
    numVars.map(vb => ({
      x: va.label, y: vb.label,
      r: pearson(filtered, va.key, vb.key)
    }))
  );
 
  return Plot.plot({
    title: "Correlation matrix — key numeric variables",
    width: 520, height: 520,
    marginLeft: 110, marginBottom: 90,
    x: { tickRotate: -35 },
    color: {
      domain: [-1, 0, 1],
      range: ["#e53935", "#fff", "#3266ad"],
      legend: true,
      label: "Pearson r"
    },
    marks: [
      Plot.cell(corrData, { x: "x", y: "y", fill: "r", inset: 0.5 }),
      Plot.text(corrData, {
        x: "x", y: "y",
        text: d => d.r.toFixed(2),
        fill: d => Math.abs(d.r) > 0.4 ? "white" : "black",
        fontSize: 12
      })
    ]
  })
}


export default function define(runtime, observer) {
  const main = runtime.module();
  function toString() { return this.url; }
  const fileAttachments = new Map([
    ["ai_jobs_merged_dataset.xlsx", {url: new URL("./files/1fb7d2c64de6035b83bb2ccbf5c62c8c86d60e8e43c09e22cbaec180b529edbde89c6f0983280bb370560c662c05cfb9ac87df52fc7c9fc2cf94429eed366cee.xlsx", import.meta.url), mimeType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", toString}]
  ]);
  main.builtin("FileAttachment", runtime.fileAttachments(name => fileAttachments.get(name)));
  main.variable(observer()).define(["md"], _1);
  main.variable(observer("data")).define("data", ["FileAttachment"], _data);
  main.variable(observer("viewof industryFilter")).define("viewof industryFilter", ["Inputs","data"], _industryFilter);
  main.variable(observer("industryFilter")).define("industryFilter", ["Generators", "viewof industryFilter"], (G, _) => G.input(_));
  main.variable(observer("viewof seniorityFilter")).define("viewof seniorityFilter", ["Inputs","data"], _seniorityFilter);
  main.variable(observer("seniorityFilter")).define("seniorityFilter", ["Generators", "viewof seniorityFilter"], (G, _) => G.input(_));
  main.variable(observer("viewof sizeFilter")).define("viewof sizeFilter", ["Inputs","data"], _sizeFilter);
  main.variable(observer("sizeFilter")).define("sizeFilter", ["Generators", "viewof sizeFilter"], (G, _) => G.input(_));
  main.variable(observer("viewof riskFilter")).define("viewof riskFilter", ["Inputs"], _riskFilter);
  main.variable(observer("riskFilter")).define("riskFilter", ["Generators", "viewof riskFilter"], (G, _) => G.input(_));
  main.variable(observer("viewof adoptionFilter")).define("viewof adoptionFilter", ["Inputs","data"], _adoptionFilter);
  main.variable(observer("adoptionFilter")).define("adoptionFilter", ["Generators", "viewof adoptionFilter"], (G, _) => G.input(_));
  main.variable(observer("viewof yearMax")).define("viewof yearMax", ["Inputs","d3","data"], _yearMax);
  main.variable(observer("yearMax")).define("yearMax", ["Generators", "viewof yearMax"], (G, _) => G.input(_));
  main.variable(observer("viewof aiOnly")).define("viewof aiOnly", ["Inputs"], _aiOnly);
  main.variable(observer("aiOnly")).define("aiOnly", ["Generators", "viewof aiOnly"], (G, _) => G.input(_));
  main.variable(observer("filtered")).define("filtered", ["data","industryFilter","seniorityFilter","sizeFilter","riskFilter","adoptionFilter","yearMax","aiOnly"], _filtered);
  main.variable(observer()).define(["filtered","d3","htl"], _11);
  main.variable(observer()).define(["d3","filtered","Plot"], _12);
  main.variable(observer()).define(["d3","filtered","Plot"], _13);
  main.variable(observer()).define(["filtered","Plot"], _14);
  main.variable(observer()).define(["d3","filtered","Plot"], _15);
  main.variable(observer()).define(["Plot","filtered"], _16);
  main.variable(observer()).define(["d3","filtered","Plot"], _17);
  main.variable(observer()).define(["d3","filtered","Plot"], _18);
  main.variable(observer()).define(["filtered","Plot"], _19);
  main.variable(observer()).define(["d3","filtered","Plot"], _20);
  main.variable(observer()).define(["d3","filtered","Plot"], _21);
  main.variable(observer()).define(["d3","filtered","Plot"], _22);
  return main;
}
